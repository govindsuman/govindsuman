<?php echo "<?php"; ?>

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class {{ $entity }} extends Model
{
    use SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = '{{$table}}';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
@foreach($fields as $field)
        '{{$field}}',
@endforeach
    ];
}
