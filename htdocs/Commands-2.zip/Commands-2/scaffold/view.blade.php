{{ '@' }}extends('layouts.app')
{{ '@' }}section('content')
    {{-- {{ '@' }}include('partials.panel-open', [ 'title' => "Add {{ $entity }}" ]) --}}
    <form action="{{'{{'}} route('{{ $resource }}.store') }}" method="POST">
        {{'{{'}}csrf_field()}}
        {{ '@' }}include('{{ $resource }}.{{ $resource }}-form')
        <div class="form-group">
            <div class="col-md-6">
                <button type="submit" dusk="save-button" class="btn btn-primary">
                    Save
                </button>
            </div>
        </div>
    </form>
    {{-- {{ '@' }}include('partials.panel-close') --}}
{{ '@' }}endsection
