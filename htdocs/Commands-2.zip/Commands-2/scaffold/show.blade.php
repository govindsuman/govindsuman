{{'@'}}extends('layouts.app')
{{'@'}}section('content')
   {{--  {{'@'}}include('partials.panel-open', [ 'title' => "Edit {{$entities}}" ]) --}}
    <form action="{{'{{'}} route('{{$resource}}.update', ${{$resource}}->id) }}" method="POST">
        {{'{{'}} method_field('PUT') }}
        {{'{{'}} csrf_field() }}
        {{'@'}}include('{{$resource}}.{{$resource}}-form')
        <div class="form-group">
            <div class="col-md-6">
                <a href="{{'{{'}}route('{{$resource}}.index')}}" class="btn btn-danger">Back</a>
                <button type="submit" dusk="update-button" class="btn btn-primary">
                    Update
                </button>
            </div>
        </div>
    </form>
    {{-- {{'@'}}include('partials.panel-close') --}}
{{'@'}}endsection
