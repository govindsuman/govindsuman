<?php echo "<?php"; ?>

namespace App\DataTables;

use Doctrine\DBAL\Query\QueryBuilder;
use Illuminate\Support\Facades\DB;
use Yajra\Datatables\Services\DataTable;

class {{$entity}}DataTable extends DataTable
{
    /**
     * Display ajax response.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function ajax()
    {
        return $this->datatables
            ->queryBuilder($this->query())
            ->addColumn(
                'action',
                function (${{$resource}}) {
                    return '
                    <a href="' . route('{{$resource}}.edit', ${{$resource}}->id) . '"
                       class="btn btn-xs btn-primary"
                       id="edit_' . ${{$resource}}->id . '"
                    >
                        <i class="glyphicon glyphicon-edit"></i> Edit
                    </a>
                    <a href="javascript:void(0)"
                       data-remote="' . route('{{$resource}}.destroy', ${{$resource}}->id) . '"
                       class="btn btn-xs btn-danger btn-delete"
                       id="delete_' . ${{$resource}}->id . '"
                    >
                        <i class="glyphicon glyphicon-trash"></i>Delete
                    </a>';
                }
            )
            ->make(true);
}

    /**
     * Get the query object to be processed by dataTables.
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query()
    {
        $query = DB::connection('mysql')
            ->table('{{$table}}')
            ->select('{{$table}}.*')
            ->where(['{{$table}}.deleted_at' => null]);
        return $this->applyScopes($query);
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\Datatables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->ajax('')
            ->addAction(['width' => '80px'])
            ->parameters([
                'dom' => 'lBfrtip',
                'buttons' => ['csv', 'excel'],
                'pageLength' => 50
            ]);
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
@foreach($fields as $field)
            '{{$field}}',
@endforeach
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return '{{$table}}datatables_' . time();
    }
}
