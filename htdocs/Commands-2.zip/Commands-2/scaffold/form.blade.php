@foreach ($fields as $field)
<div class="row form-group{{'{{'}} $errors->has('{{$field}}') ? ' has-error' : '' }}">
    <div class="col-md-4">
        <label for="{{$field}}" class="col-md-4 control-label">{{ $entity . ' ' . ucwords($field) }}</label>
    </div>
    <div class="col-md-7">
        <input id="{{$field}}"
               type="text"
               class="form-control"
               name="{{$field}}"
               value="{{'{{'}} old('{{$field}}') ?? ${{$resource}}->{{$field}} }}"
        >
    </div>
</div>
@endforeach
{{-- {{'@'}}push('scripts') --}}
<script type="text/javascript">
    $("form").submit(function () {
        // Insert client side validators here
        return true;
    });
</script>
{{-- {{'@'}}endpush --}}
