{{'@'}}extends('layouts.app')
{{'@'}}section('content')
   {{--  {{'@'}}include('partials.panel-open', [ 'title' => "Manage {{$entities}}" ]) --}}
    <div class="form-group">
        <a href="{{'{{'}} route('{{$resource}}.create') }}" class="btn btn-primary">Create New {{$entity}}</a>
    </div>
    <?php echo '{!!';?> $dataTable->table(['class' => 'table table-bordered','id' =>'{{$resource}}-table']) !!}
    <a href="{{'{{'}} route('{{$resource}}.create') }}" class="btn btn-primary">Create New {{$entity}}</a>
    <?php echo '{!!';?> $dataTable->scripts() !!}
    <script type="text/javascript">
        $('#{{$resource}}-table').on('click', '.btn-delete[data-remote]', function (e) {
            e.preventDefault();
            if (confirm("Are you sure you want to delete")) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                var url = $(this).data('remote');
                // confirm then
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    dataType: 'json',
                    data: {method: '_DELETE', submit: true}
                }).always(function (data) {
                    $('#{{$resource}}-table').DataTable().draw(false);
                });
            }
        });
    </script>
    {{-- {{'@'}}include('partials.panel-close') --}}
{{'@'}}endsection

{{-- {{'@'}}push('scripts') --}}
    {{-- <script src="/vendor/datatables/buttons.server-side.js"></script>
    
{{-- {{'@'}}endpush --}}
