<?php

namespace App\Console\Commands;

use Doctrine\Common\Inflector\Inflector;
use Illuminate\Console\Command;

class ScaffoldCrudCommand extends Command
{
    /**
     * Generates a collection of files needed for building out a laravel-datatables crud editor for a table
     *
     * @var string
     */
    protected $signature = 'scaffold:crud
                            { resource? :  The model resource to create. All lower case.         }
                            { table?   :  Optional. The table name resource to create (if different from the resource name).    }
                            ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '
        Generate scaffolding for a new resource. 
        A datatables index and crud forms will be generated';

    private $resource;
    private $entity;
    private $table;
    private $fields = [];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     * @throws \Exception
     */
    public function handle()
    {
        if (empty($this->argument('resource'))) {
            $this->resource = Inflector::singularize(strtolower($this->ask('What should we call this resource?')));
        } else {
            $this->resource = Inflector::singularize(strtolower($this->argument('resource')));
        }
        $this->entity = ucwords($this->resource);

        if (empty($this->argument('table'))) {
            $this->table = $this->ask('What table name would you like to use?', Inflector::pluralize($this->resource));
        } else {
            $this->table = $this->argument('table')
                ? Inflector::pluralize($this->argument('table'))
                : Inflector::pluralize($this->resource);
        }

        while ($fieldname = $this->ask('Add a field to the ' . $this->table . ' table (enter blank when done)?')) {
            if (empty($fieldname)) {
                break;
            }
            $this->fields[] = $fieldname;
        }

        $this->info('Generating migration...');
        $this->generateMigration();

        if (!file_exists($this->getModelFilePath())) {
            $this->info('Generating model...');
            $this->generateModel();
        } else {
            $this->info('Skipping model generation since ' . $this->getModelFilePath() . ' exists.');
        }

        if (!file_exists($this->getDataTableFilePath())) {
            $this->info('Generating data table...');
            $this->generateDataTable();
        } else {
            $this->info('Skipping datatable generation since ' . $this->getDataTableFilePath() . ' exists.');
        }

        if (!file_exists($this->getControllerFilePath())) {
            $this->info('Generating controller...');
            $this->generateController();
        } else {
            $this->info('Skipping controller generation since ' . $this->getControllerFilePath() . ' exists.');
        }

        if (!file_exists($this->getViewFolderPath())) {
            $this->info('Generating view folder...');
            $this->generateView('folder');
            $this->info('Generating create view...');
            $this->generateView('create');
            $this->info('Generating view form...');
            $this->generateView('form');
            $this->info('Generating view index...');
            $this->generateView('index');
            $this->info('Generating view show...');
            $this->generateView('show');
            $this->info('Generating routes...');
        } else {
            $this->info('Skipping view generation since ' . $this->getViewFolderPath() . ' exists.');
        }
        $this->generateRoutes();
        $this->info('');
        $this->info('That\'s it. Now go inspect and finish the scaffolding files generated.');
    }

    // Generators -----------------------------------------------------------------------------------------------------

    /**
     * Generate the migration
     */
    private function generateMigration()
    {
        $filename = $this->getMigrationFilePath();
        $data = $this->generateMigrationContent();
        file_put_contents($filename, $data);
    }

    /**
     * Get the migration file path
     * @return string
     */
    private function getMigrationFilePath()
    {
        return database_path(
            'migrations/'
            . date('Y_m_d_His')
            . '_'
            . str_slug(
                'Create ' . $this->table . ' Table',
                '_'
            )
            . '.php'
        );
    }

    /**
     * Generate the Eloquent model
     */
    private function generateModel()
    {
        $filename = $this->getModelFilePath();
        $data = $this->generateModelContent();
        file_put_contents($filename, $data);
    }

    /**
     * Get the file path to the eloquent model we are going to create
     * @return string
     */
    private function getModelFilePath()
    {
        return app_path('Models/' . $this->entity . '.php');
    }

    /**
     *
     */
    private function generateController()
    {
        $filename = $this->getControllerFilePath();
        $data = $this->generateControllerContent();
        file_put_contents($filename, $data);
    }

    /**
     * Get the file path to the controller we are going to create
     * @return string
     */
    private function getControllerFilePath()
    {
        return app_path('Http/Controllers/' . $this->entity . 'Controller.php');
    }

    /**
     * @param string $component
     * @throws \Exception
     */
    private function generateView(string $component)
    {
        switch ($component) {
            case 'create':
                $this->generateViewCreate();
                break;
            case 'folder':
                $this->generateViewFolder();
                break;
            case 'index':
                $this->generateViewIndex();
                break;
            case 'form':
                $this->generateViewForm();
                break;
            case 'show':
                $this->generateViewShow();
                break;
            case 'datatable':
                $this->generateDataTable();
                break;
        }
    }

    /**
     * Make sure the folder exists
     */
    private function generateViewFolder()
    {
        $folder = $this->getViewFolderPath();
        mkdir($folder);
    }

    /**
     * Get the folder path to the views we are going to create
     * @return string
     */
    private function getViewFolderPath()
    {
        return resource_path('views/' . $this->resource);
    }

    /**
     * Generate the create page
     */
    private function generateViewCreate()
    {
        $filename = resource_path('views/' . $this->resource . '/create.blade.php');
        $data = $this->generateViewCreateContent();
        file_put_contents($filename, $data);
    }

    /**
     * Generate the form page
     */
    private function generateViewForm()
    {
        $filename = resource_path('views/' . $this->resource . '/' . $this->resource . '-form.blade.php');
        $data = $this->generateViewFormContent();
        file_put_contents($filename, $data);
    }

    /**
     * Generate the index page
     */
    private function generateViewIndex()
    {
        $filename = resource_path('views/' . $this->resource . '/index.blade.php');
        $data = $this->generateViewIndexContent();
        file_put_contents($filename, $data);
    }

    /**
     * Generate the show page
     */
    private function generateViewShow()
    {
        $filename = resource_path('views/' . $this->resource . '/show.blade.php');
        $data = $this->generateViewShowContent();
        file_put_contents($filename, $data);
    }

    /**
     * Generate the datatable
     */
    private function generateDataTable()
    {
        $filename = $this->getDataTableFilePath();
        $data = $this->generateDataTableContent();
        file_put_contents($filename, $data);
    }

    /**
     * Get the file path to the datatable we are going to generate
     * @return string
     */
    private function getDataTableFilePath()
    {
        return app_path('DataTables/' . $this->entity . 'DataTable.php');
    }

    /**
     * Generate routes
     */
    private function generateRoutes()
    {
        $lowered = strtolower($this->entity);
        $resourceRoute = "Route::resource('{$lowered}', '{$this->entity}Controller');";
        $this->info('Add the following to your routes file inside the auth group middleware:');
        $this->info('');
        $this->info($resourceRoute);
    }


    // Content --------------------------------------------------------------------------------------------------------


    /**
     * Generate a migration file content
     * @return string
     */
    private function generateMigrationContent()
    {
        return view(
            'scaffold.migration',
            [
                'table' => $this->table,
                'Entities' => ucwords(Inflector::pluralize($this->entity)),
                'fields' => $this->fields
            ]
        );
    }


    /**
     * Generate an eloquent model content
     * @return string
     */
    private function generateModelContent()
    {
        return view(
            'scaffold.model',
            [
                'table' => $this->table,
                'fields' => $this->fields,
                'entity' => $this->entity
            ]
        );
    }



    /**
     * Generate the content for the create blade
     * @return string
     */
    private function generateViewCreateContent()
    {
        return view('scaffold.view', ['resource' => $this->resource, 'entity' => $this->entity]);
    }



    /**
     * Generate the content for the edit form blade
     * @return string
     */
    private function generateViewFormContent()
    {
        return view(
            'scaffold.form',
            [
                'entity' => $this->entity,
                'resource' => $this->resource,
                'fields' => $this->fields
            ]
        );
    }



    /**
     * Generate the content for the index blade
     * @return string
     */
    private function generateViewIndexContent()
    {
        return view(
            'scaffold.index',
            [
                'entity' => $this->entity,
                'resource' => $this->resource,
                'entities' => Inflector::pluralize($this->entity)
            ]
        );
    }


    /**
     * Generate the content for the show blade
     * @return string
     */
    private function generateViewShowContent()
    {
        return view(
            'scaffold.show',
            [
                'resource' => $this->resource,
                'entities' => Inflector::pluralize($this->entity)
            ]
        );
    }


    /**
     * Generate the content for the index blade
     * @return string
     */
    private function generateDataTableContent()
    {
        return view(
            'scaffold.datatable',
            [
                'resource' => $this->resource,
                'entity' => $this->entity,
                'entities' => Inflector::pluralize($this->entity),
                'table' => $this->table,
                'fields' => $this->fields,
            ]
        );
    }


    /**
     * Generate the content for the Controller file
     */
    private function generateControllerContent()
    {
        $required_array = [];
        foreach ($this->fields as $field) {
            $required_array[] = '"' . $field . '" => "required" ';
        }
        $required_fields = implode(",\n", $required_array);
        return view(
            'scaffold.controller',
            [
                'resource' => $this->resource,
                'entity' => $this->entity,
                'entities' => Inflector::pluralize($this->entity),
                'table' => $this->table,
                'fields' => $this->fields,
                'required_fields' => $required_fields,
            ]
        );
    }

}
